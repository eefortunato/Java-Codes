/**
 * ClientMain.java
 * 
 * @version $Id: ClientMain.java,v 1.0 2013/11/26 08:00am $
 * 
 * @author Pavan Kumar Pallerla
 * @author Eric Fortunato
 * 
 * 
 */
public class ClientMain {

	/**
	 * main method
	 * 
	 * @param args
	 *            first argument is the server's ip address and the second one
	 *            is the port number
	 */
	public static void main(String[] args) {

		try {
			ClientView theView = new ClientView();
			TossModel theModel = new TossModel();
			ClientController theController = new ClientController(theView,
					theModel, args[0], Integer.parseInt(args[1]));
			theView.setVisible(true);

		} catch (NumberFormatException nfe) {
			System.out.println("Port entered" + args[1]
					+ " is not a valid number");
		}

	}

}

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

//import CookieView.GameButton;


public class CookieController {
	
	CookieModel model;
	static CookieView view = new CookieView();
	
	CookieController(CookieModel m) {
		model = m;
	}

}


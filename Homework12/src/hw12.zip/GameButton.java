import java.awt.Color;

import javax.swing.JButton;

    class GameButton extends JButton {
    	
    	int xCoordinate;
    	int yCoordinate;
    
    	GameButton() {
    		this.setBackground(Color.BLACK);
    		addMouseListener(new ButtonListener());
    		setEnabled(true);
    	}
    	
//    	GameButton(int x, int y) {
//    		this.set
//    	}
    	
    }

public class Cashier {

	final double discount = 0.85;
	private double moneyInCounter = 0;
	private double bill = 0;
	
	public void payMoney(double money) {
		moneyInCounter += money;
	}
	public double getMoneyInCounter () {
		return moneyInCounter;
	}
	
	public double getDiscountedAmount(Comodity comodity) {
		double amount = comodity.getPrice() * comodity.quantityPurchased;
		if (comodity.isEligibleForDiscount()) {
			return amount * discount;
		} else {
			return amount;
		}
	}
	
	public double checkOutCustomer(double amount) {
		this.bill += amount;
		return this.bill;
	}
 	
}

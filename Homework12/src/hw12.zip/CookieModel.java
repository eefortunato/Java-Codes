

public class CookieModel {
	
	GameButton[][] buttons = new GameButton[10][10];
	
	CookieModel (GameButton[][] grid) {
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10 ; j++) {
				this.buttons[i][j] = grid[i][j];
				//this.buttons[i][j].setText("B");
				//this.buttons[i][j].setBorderPainted(false);
			}
		}
	}
	
	CookieModel (GameButton b) {
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10 ; j++) {
				if (b.getX() == i && b.getY() == j) {
					buttons[i][j].setText("C");
				} else if (i == b.getX()+1 && b.getY() == j+1) {
					buttons[i][j].setText("X");
				} else if (i == b.getX()+1 && b.getY() == j) {
					buttons[i][j].setText("X");
				} else if (i == b.getX()+1 && b.getY() == j-1) {
					buttons[i][j].setText("X");
				} else if (i == b.getX() && b.getY() == j-1) {
					buttons[i][j].setText("X");
				} else if (i == b.getX()-1 && b.getY() == j-1) {
					buttons[i][j].setText("X");
				} else if (i == b.getX()-1 && b.getY() == j) {
					buttons[i][j].setText("X");
				} else if (i == b.getX()-1 && b.getY() == j+1) {
					buttons[i][j].setText("X");
				} else if (i == b.getX() && b.getY() == j+1) {
					buttons[i][j].setText("X");
				} else {
					buttons[i][j].setText("B");
				}
				
			}
		}
	}	
	
	public String getContent(GameButton b) {
		return buttons[b.getX()][b.getY()].getText();
	}

}

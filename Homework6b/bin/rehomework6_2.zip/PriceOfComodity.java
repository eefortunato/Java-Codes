
public interface PriceOfComodity {

	abstract public void setPrice(double price);
}


public class Lemon extends Comodity implements PriceOfComodity{

	int amountForDiscount = 9;
	private final double weight = 3.0;
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public boolean isEligibleForDiscount(){
        if(this.quantityPurchased > amountForDiscount){
                return true;
        }
        return false;
	 }
	
	public double getWeight(){
        return this.weight;
	 }
}

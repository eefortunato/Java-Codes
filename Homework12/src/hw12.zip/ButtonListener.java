import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

	class ButtonListener implements MouseListener {
		

		@Override
		public void mouseClicked(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			
			GameButton button = (GameButton)e.getSource();
			String content = CookieView.model.getContent(button);
			if (content.equals("B")) {
				CookieController.view.setBlackBackGround(button);
//				button.setBackground(Color.BLACK);
//				button.setContentAreaFilled(false);
//				button.setOpaque(true);
			} else if (content.equals("X")) {
				CookieController.view.setX(button);
			} else {
				CookieController.view.setCookieImage(button);
			}
		}
		
	}
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.Image;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;


public class CookieView extends JFrame{
	private final String imagePath = "cookie.jpeg";
	private JPanel content;
	private GameButton[][] grid;
	private final int gridSize = 10;
	static CookieModel model;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CookieView window = new CookieView();
					window.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
     * Create the application.
     */
    public CookieView() {
    	initialize();
    	model = new CookieModel(grid);
    	
    }
    
    /**
     * Initialize the contents of the frame.
     */
	private void initialize() {
		this.setTitle("Player - I: Click on a button to set the cookie");
		this.setResizable(false);
		this.setBounds(100, 100, 450, 300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		content = new JPanel();
		content.setLayout(null);
		
		setLayout(new GridLayout(10, 10));
		grid = new GameButton[gridSize][gridSize];
		
		for(int i = 0; i < gridSize; i++) 
            for(int j = 0; j < gridSize; j++) {
            	grid[i][j] = new GameButton();
            	add(grid[i][j]);
            }
		
	}
    	
    
    
//    private void initialize() {
//        frame = new JFrame("Find The Cookie v1.00");
//        frame.setResizable(false);
//        frame.setBounds(100, 100, 450, 300);
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//
//        content = new JPanel();
//        content.setLayout(null);
//
//        grid = new FindTheCookieGrid(10);
//        grid.setBounds(0, 0, 444, 251);
//        content.add(grid);
//
//        menuBar = new JMenuBar();
//        frame.setJMenuBar(menuBar);
//
//        file = new JMenu("File");
//        menuBar.add(file);
//
//        newGame = new JMenuItem("New Game");
//        file.add(newGame);
//
//        options = new JMenuItem("Options...");
//        file.add(options);
//
//        close = new JMenuItem("Close");
//        file.add(close);
//
//        help = new JMenu("Help");
//        menuBar.add(help);
//
//        instructions = new JMenuItem("How to play?");
//        help.add(instructions);
//
//        about = new JMenuItem("About...");
//        help.add(about);
//
//        frame.setContentPane(content);
//    }
    public void setBlackBackGround(GameButton b) {
    	b.setBackground(Color.BLACK);
		b.setContentAreaFilled(false);
		b.setOpaque(true);
    }
    
    public void setX(GameButton b) {
    	b.setForeground(Color.RED);
    }
    
    public void setCookieImage(GameButton b) {
    	try {
    		Image img = ImageIO.read(getClass().getResource(imagePath)); //
        	b.setIcon(new ImageIcon(img));
    	} catch (IOException ioe) {
    		
    	}
    }

}

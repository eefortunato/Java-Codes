
public class Comodity {
	public double price;
	public String colour;
	public double quantityRemaining;
	public double quantityPurchased;
	
	
	public double getPrice() {
		return price;
	}
	
	public boolean isQuantitySufficient(double quantity) {
		return quantityRemaining >= quantity;
	}
	
	public void setQuantity(double quantity) {
		this.quantityPurchased = quantity;
		quantityRemaining -= quantity;
	}
	
	public void setColour(String colour) {
		this.colour = colour;
	}
	
	public String getColour() {
		return this.colour;
	}

	public boolean isEligibleForDiscount() {
		// TODO Auto-generated method stub
		return false;
	}
 
}

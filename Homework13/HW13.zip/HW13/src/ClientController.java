import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;

/**
 * ClientController.java
 * 
 * @version $Id: ClientController.java,v 1.0 2013/11/26 08:00am $
 * 
 * @author Pavan Kumar Pallerla
 * @author Eric Fortunato
 * 
 * 
 */
public class ClientController {

	private ClientView theView;
	private TossModel theModel;
	private int portNumber;
	private String ip;

	/**
	 * Constructor for ClientController
	 * 
	 * @param view
	 *            ClientView object
	 * @param model
	 *            TossModel object
	 * @param serverIpAddress
	 *            sets the server's ip address
	 * @param port
	 *            sets the port on which the server listens to client
	 */
	public ClientController(ClientView view, TossModel model,
			String serverIpAddress, int port) {
		this.theView = view;
		this.theModel = model;
		this.portNumber = port;
		this.ip = serverIpAddress;

		this.theView.addTossListener(new TossListener());
	}

	/**
	 * TossListener is action listener class for toss button
	 * 
	 * @author Pavan Kumar Pallerla & Eric Fortunato
	 * 
	 */
	class TossListener implements ActionListener {

		@Override
		/**
		 * called when toss button is clicked
		 */
		public void actionPerformed(ActionEvent arg) {
			int selectedSide, player;

			try {
				selectedSide = theView.getSelectedRadioButton();
				theModel.setSelectedSide(selectedSide);
				player = theModel.getPlayer();
				if (selectedSide == theModel.getWinningSide()) {
					theModel.setWinner(player);
				} else {
					theModel.setWinner(player);
				}
				theView.setWinner(player);
				connection();
			} catch (Exception e) {

			}
		}

		/**
		 * Opens the server socket and writes model object on to
		 * ObjectOutputStream
		 */
		private void connection() {
			try {
				Socket serverSocket = new Socket(ip, portNumber);
				BufferedReader in = new BufferedReader(new InputStreamReader(
						serverSocket.getInputStream()));
				ObjectOutputStream out = new ObjectOutputStream(
						serverSocket.getOutputStream());
				out.writeObject(theModel);
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}

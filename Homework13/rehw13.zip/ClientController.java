import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;


public class ClientController {

	private ClientView theView;
	private ClientModel theModel;
	private int portNumber;
	
	public ClientController(ClientView view, ClientModel model, int port) {
		this.theView = view;
		this.theModel = model;
		this.portNumber = port;
		ClientModel cm = null;
		
		try {
			ServerSocket serverSocket = new ServerSocket(portNumber);
			Socket client = serverSocket.accept();
			ObjectInputStream in = new ObjectInputStream(client.getInputStream());
			theModel = (ClientModel)in.readObject();
			theView.setWinner(theModel.getWinner());
			theView.setSelectedSide(theModel.getWinner());
			in.close();
//		    BufferedReader in = new BufferedReader(
//		        new InputStreamReader(serverSocket.getInputStream()));
//		    ObjectOutputStream out = new ObjectOutputStream(serverSocket.getOutputStream());
//		    out.writeObject(theModel);
//		    out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException cnf) {
			System.out.println("ClientModel class is not found");
		}
	}
}

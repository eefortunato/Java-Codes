import java.util.Scanner;


public class Customer {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Apple apple = new Apple("Yellow");
		Avocado avocado = new Avocado();
		Banana banana = new Banana();
		Cucumber cucumber = new Cucumber();
		Grape grape = new Grape();
		Kiwi kiwi = new Kiwi();
		Lemon lemon = new Lemon();
		Melon melon = new Melon();
		Orange orange = new Orange();
		Pepper pepper = new Pepper();
		Pineapple pineapple = new Pineapple();
		PassionFruit pfruit = new PassionFruit();
		
		Cashier c[] = new Cashier[10];
		long counterNumber = System.currentTimeMillis() % 10;
		
		
		
		boolean picked = false;
		
		do {
			System.out.println("Pick a number adjacent to any item : ");
			System.out.println("1. Banana");
			System.out.println("2. Melon");
			System.out.println("3. Grapes");
			System.out.println("4. Apples");
			System.out.println("5. Oranges");
			System.out.println("6. Lemons");
			System.out.println("7. Kiwis");
			System.out.println("8. Pepper");
			System.out.println("9. Cucumber");
			System.out.println("10. Pineapple");
			System.out.println("11. Passion fruit");
			System.out.println("12. Avocados");
			System.out.println("13. Exit Menu");
			if (sc.hasNextInt() ) { 
				int selection = sc.nextInt();
				int quantity;
					switch (selection) {
					case 1: System.out.println("Enter weight of Banana you would like to purchase: ");
					quantity = sc.nextInt();
					if (banana.isQuantitySufficient(quantity)) {
						banana.setQuantity(quantity);
						c[(int) counterNumber].checkOutCustomer(c[(int) counterNumber].getDiscountedAmount(banana));
					}
					continue;
					
					case 2: System.out.println("Enter weight of Melon you would like to purchase: ");
					quantity = sc.nextInt();
					if (melon.isQuantitySufficient(quantity)) {
						melon.setQuantity(quantity);
						c[(int) counterNumber].checkOutCustomer(c[(int) counterNumber].getDiscountedAmount(melon));
					}
					continue;
					
					case 3: System.out.println("Enter weight of Grapes you would like to purchase: ");
					quantity = sc.nextInt();
					if (grape.isQuantitySufficient(quantity)) {
						grape.setQuantity(quantity);
						c[(int) counterNumber].checkOutCustomer(c[(int) counterNumber].getDiscountedAmount(grape));
					}
					continue;
					
					case 4: System.out.println("Enter no. of bags of Apples you would like to purchase: ");
					quantity = sc.nextInt();
					if (apple.isQuantitySufficient(quantity)) {
						apple.setQuantity(quantity);
						c[(int) counterNumber].checkOutCustomer(c[(int) counterNumber].getDiscountedAmount(apple));
					}
					continue;

					case 5: System.out.println("Enter no. of bags of oranges you would like to purchase: ");
					quantity = sc.nextInt();
					if (orange.isQuantitySufficient(quantity)) {
						orange.setQuantity(quantity);
						c[(int) counterNumber].checkOutCustomer(c[(int) counterNumber].getDiscountedAmount(orange));
					}
					continue;

					case 6: System.out.println("Enter no. of bags of lemons you would like to purchase: ");
					quantity = sc.nextInt();
					if (lemon.isQuantitySufficient(quantity)) {
						lemon.setQuantity(quantity);
						c[(int) counterNumber].checkOutCustomer(c[(int) counterNumber].getDiscountedAmount(lemon));
					}
					continue;

					case 7: System.out.println("Enter no. of kiwis you would like to purchase: ");
					quantity = sc.nextInt();
					if (kiwi.isQuantitySufficient(quantity)) {
						kiwi.setQuantity(quantity);
						c[(int) counterNumber].checkOutCustomer(c[(int) counterNumber].getDiscountedAmount(kiwi));
					}
					continue;

					case 8: System.out.println("Enter no. of peppers you would like to purchase: ");
					quantity = sc.nextInt();
					if (pepper.isQuantitySufficient(quantity)) {
						pepper.setQuantity(quantity);
						c[(int) counterNumber].checkOutCustomer(c[(int) counterNumber].getDiscountedAmount(pepper));
					}
					continue;

					case 9: System.out.println("Enter no. of cucumber you would like to purchase: ");
					quantity = sc.nextInt();
					if (cucumber.isQuantitySufficient(quantity)) {
						cucumber.setQuantity(quantity);
						c[(int) counterNumber].checkOutCustomer(c[(int) counterNumber].getDiscountedAmount(cucumber));
					}
					continue;
					
					case 10: System.out.println("Enter no. of pineapples you would like to purchase: ");
					quantity = sc.nextInt();
					if (pineapple.isQuantitySufficient(quantity)) {
						pineapple.setQuantity(quantity);
						c[(int) counterNumber].checkOutCustomer(c[(int) counterNumber].getDiscountedAmount(pineapple));
					}
					continue;
					
					case 11: 
					System.out.println("Enter no. of passion fruits you would like to purchase: ");
					quantity = sc.nextInt();
					if (pfruit.isQuantitySufficient(quantity)) {
						pfruit.setQuantity(quantity);
						c[(int) counterNumber].checkOutCustomer(c[(int) counterNumber].getDiscountedAmount(pfruit));
					}
					continue;
					
					case 12: 
					System.out.println("Enter no. of Avocados you would like to purchase: ");
					quantity = sc.nextInt();
					if (avocado.isQuantitySufficient(quantity)) {
						avocado.setQuantity(quantity);
						c[(int) counterNumber].checkOutCustomer(c[(int) counterNumber].getDiscountedAmount(avocado));
					}
					continue;
					
					case 13: 
						break;
					
					default : 
						break;	

					}
			}
		} while (!picked );
		
		
		

	}

}
